<?php if(isset($_GET['success']) && $_GET['success']=="true"){
    include_once("../../co.php"); 
    db::stmt("UPDATE `availability` SET `description` = 'true' WHERE `availability`.`id` = '5' AND `namer`='hasSubscribeMonthly';");
    header("Location: ".site::url(2,true)); exit();
}?><html>
    <head> 
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width" />
        <title>Admin</title>
    </head>
    <body style="position:relative;">
        <div style="width:100%;max-width:500px;margin:auto;height:100%;position:relative;">
            <iframe src="./web/index.html" style="width:100%;height:100%;border:0;padding: 0 2px;
            background: url(https://cocohairsignature.com/img/n/addloader.gif) center center no-repeat;background-size:191px 147px;"></iframe>
        </div>
    </body>
    
</html>