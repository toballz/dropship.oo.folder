<?php include_once("../co.php");
require_once('./stripe-php-master/init.php');

function mailReceiptAlert($oid, $customerEmsil){
	$mailer_header = "From: support@cocohairsignature.com\r\n".
    	    "Reply-To: support@cocohairsignature.com\r\n".
    	    "X-Mailer: PHP/".phpversion(); 

    $alertSMSMessage="A new appointment has been set\r\n\n----------------------------\r\n".site::url(1)."/pages/receipt.php?ords=".$oid;
 	//sms me alert                                                  //sms coco alert
 	$mySms="8506317422@tmomail.net,elisha4b@yahoo.com";             $cocoSms="cocohairsignature@gmail.com,2244401819@txt.att.net";
	mail($mySms, '!!', $alertSMSMessage, $mailer_header);           if(islive){mail($cocoSms, '!!',$alertSMSMessage,$mailer_header);}

	//Email customer receipt
    $customerReceiptMessage=file_get_contents(site::url(1)."/pages/receipt.php?ords=".$oid);
	mail($customerEmsil.",test-gzyk8oipb@srv1.mail-tester.com",
	     'Your Hair Appointment Confirmation | CocoHairSignature',
	     "<a href='".site::url(1)."/pages/receipt.php?ords=".$oid."'>View your appointment details here - ".site::url(1)."/pages/receipt.php?ords=".$oid."</a><br/>".$customerReceiptMessage,
	     "MIME-Version: 1.0\r\n"."Content-type:text/html;charset=UTF-8\r\n".$mailer_header);
}

//secret Stripe API key
\Stripe\Stripe::setApiKey(tools::stripe_Secret_key_API());

// Handle the incoming webhook event
$payload = @file_get_contents('php://input');
$event = null;
try {
    $event = \Stripe\Webhook::constructEvent($payload, $_SERVER['HTTP_STRIPE_SIGNATURE'], tools::stripe_Signing_Secret());
} catch(\UnexpectedValueException $e) {
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    http_response_code(400);
    exit();
}

// Handle the event
switch ($event->type) {
    case 'payment_intent.succeeded':
        //Get metadata from PaymentIntent
        $paymentIntent = $event->data->object; // Contains a Stripe PaymentIntent
        //get orderID 
        $Order_Id = $paymentIntent->metadata->orderID;
        $Order_Email = $paymentIntent->metadata->orderEmail;
		//file_put_contents("./akd.txt", $Order_Email);
        //update if has paid to 1
        db::stmt("UPDATE `schedulee` SET `haspaid` = '1' WHERE `schedulee`.`rida` = '$Order_Id';");
        //
        mailReceiptAlert($Order_Id,trim($Order_Email));
        break;
    // Handle other event types as needed
}
http_response_code(200);
