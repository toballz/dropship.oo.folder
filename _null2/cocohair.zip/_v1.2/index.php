<?php include_once("./co.php");?><!DOCTYPE html>
<html  >
<head>
    
  <?php include(dirr."/i/head.php");?>
  <title>Home</title>
</head>


<body>
<?php include(dirr."/i/header.php");?>

<section data-bs-version="5.1" class="header14 cid-sRC4G1AxNX mbr-fullscreen" style="background-color: #7f27b1;" id="header14-k">

    

    
    <style type="text/css">.mbr-section-btn.mt-3{text-align:center;}.mbr-section-btn.mt-3>a{margin:0;margin-right:12px; margin-bottom:4px;}.carol{position: relative;top:0;left: 0;width:500%;display:flex;
            animation-duration:23s;animation-name:tonext;animation-iteration-count:infinite;}
            
@media screen and (max-width: 480px){
    .cid-sRC4G1AxNX .image-wrapper img{
    height: 84%;}.header14.cid-sRC4G1AxNX.mbr-fullscreen{padding-bottom:0 !important;
    min-height: 84vh;}
    .carol-moth-paren{align-items:start !important;}.mbr-fullscreen{padding-top:1.2rem !important;}.col-12.col-md-6.image-wrapper{margin:0 !important}
    .carol-moth-paren{  height: 399px !important;}.asas{font-size:29px !important;text-align:center;
    
    font-family: math !important;
    line-height: 35px !important; margin-top:17px !important}}
        @keyframes tonext {
          0%{left: 0} 10% {left: 0;} 20% {left: -100%;} 30% {left: -100%;} 40% {left: -200%; } 50% {left: -200%; }60% {left: -300%; }70% {left: -300%; }80% .carol-moth-paren{left: -400%; }90% {left: -400%; }}
          .carol-moth-paren{height:600px;overflow:hidden;display:flex;align-items:center;}
        @media(min-width:769px) and (max-width:1000px){.carol-moth-paren{height:440px}}

    </style>
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-md-6 image-wrapper">
                <div class="carol-moth-paren"><div>
                    <div class="carol">
                        <div><img src="<?php echo site::url(1);?>/img/n/1.jpg" alt="Mobirise"></div>
                        <div><img src="<?php echo site::url(1);?>/img/n/2.jpg" alt="Mobirise"></div>
                        <div><img src="<?php echo site::url(1);?>/img/n/3.jpg" alt="Mobirise"></div>
                        <div><img src="<?php echo site::url(1);?>/img/n/4.jpg" alt="Mobirise"></div>
                        <div><img src="<?php echo site::url(1);?>/img/n/5.jpg" alt="Mobirise"></div>
                    </div></div>
                </div>
            </div>
            <div class="col-12 col-md">
                <div class="text-wrapper">
                    <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1 asas" style="font-size:37px"><strong>Welcome To Coco Hair Signature, LLC</strong></h1>
                    <div class="mbr-section-btn mt-3"><a class="btn btn-secondary display-4" style="background:#f773c1 !important" href="<?php echo site::url(1);?>/pages/hairlist.php">Book Now</a><a class="btn btn-info display-4" href="http://shop.<?php echo site::url(3);?>">Shop Online</a><a class="btn btn-warning display-4" href="<?php echo site::url(1);?>/pages/classes.php">📚1on1 Classes</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features11 cid-sRCAkgoGqW" id="aboutus" style="background-position: 50% 50%; background-size: cover; background-repeat: no-repeat; background-image: url(<?php echo site::url();?>/assets/images/background8.jpg);color:#faebd7;background:linear-gradient(90deg, rgb(40 127 187) 0%, rgb(127 39 199) 59%, rgb(124 39 177) 95%);">
    
    
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg">
                <div class="card-wrapper">
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style mb-4 display-2">
                            <strong>ABOUT ME</strong></h4>
                            <div style=""><img src="<?php echo site::url(1);?>/img/n/coco.jpeg" style="max-width:345px;margin:auto;margin-bottom:52px" /></div>
                        <div class="mbr-text mbr-fonts-style mb-4 display-7">HI, I’M COCO! <b style="border-top:1px dashed #ccc;text-align:center;font-size:24px;color:#ffe6ff;">Ms. 3hrs or less!😁</b>
<br>
<div style="margin-left:16px;"><br>I’m a young African-American talented self taught braider. <br>I have been braiding ever since <wbr>I was 7 years old. <wbr>I have a gift/passion for braiding and so I am here to offer you the best service at your braiding appointment. <wbr>I’m located in Grayslake Illinois.
<br>Thank you for choosing Coco and considering me as your braider. I look forward to slaying your braids!<br></div></di ></div>
                </div>
            </div> 
        </div>
    </div>
</section>

<section class="gallery5 mbr-gallery cid-sRC7I9fXo4" id="gallery5-l" style="background: linear-gradient(90deg, rgb(43 124 188) 0%, rgb(178 142 208) 59%, rgb(214 145 202) 95%);">
    <div class="container">
        
        <div class="row mbr-gallery mt-4" style="margin-top:0 !important">
            <div class="col-12 col-md-6 col-lg-3 item gallery-image active">
                <div class="item-wrapper" data-toggle="modal" data-bs-toggle="modal" data-target="#sRH7Kx4CvK-modal" data-bs-target="#sRH7Kx4CvK-modal">
                    <img class="w-100" src="<?php echo site::url(1);?>/img/n/dowwenload-4-400x721.jpeg" alt="" data-slide-to="0" data-bs-slide-to="0" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK">
                    <div class="icon-wrapper">
                        <span class="mobi-mbri mobi-mbri-search mbr-iconfont mbr-iconfont-btn"></span>
                    </div>
                </div>
                
            </div>
            <div class="col-12 col-md-6 col-lg-3 item gallery-image active">
                <div class="item-wrapper" data-toggle="modal" data-bs-toggle="modal" data-target="#sRH7Kx4CvK-modal" data-bs-target="#sRH7Kx4CvK-modal">
                    <img class="w-100" src="<?php echo site::url(1);?>/img/n/thumbnail-6-1080x1478.jpeg" alt="" data-slide-to="2" data-bs-slide-to="2" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK">
                    <div class="icon-wrapper">
                        <span class="mobi-mbri mobi-mbri-search mbr-iconfont mbr-iconfont-btn"></span>
                    </div>
                </div>
                
            </div><!--<div class="col-12 col-md-6 col-lg-3 item gallery-image active">
                <div class="item-wrapper" data-toggle="modal" data-bs-toggle="modal" data-target="#sRH7Kx4CvK-modal" data-bs-target="#sRH7Kx4CvK-modal">
                    <img class="w-100" src="assets/images/thumbnail-7-506x824.jpeg" alt="" data-slide-to="3" data-bs-slide-to="3" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK">
                    <div class="icon-wrapper">
                        <span class="mobi-mbri mobi-mbri-search mbr-iconfont mbr-iconfont-btn"></span>
                    </div>
                </div>
                
            </div>-->
            
            
            
        </div>

        <div class="modal mbr-slider" tabindex="-1" role="dialog" aria-hidden="true" id="sRH7Kx4CvK-modal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="carousel slide carousel-fade" id="lb-sRH7Kx4CvK" data-interval="5000" data-bs-interval="5000">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="<?php echo site::url(1);?>/img/n/dowwenload-4-400x721.jpeg" alt="">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?php echo site::url(1);?>/img/n/thumbnail-6-1080x1478.jpeg" alt="">
                                </div><div class="carousel-item">
                                    <img class="d-block w-100" src="<?php echo site::url(1);?>/img/n/thumbnail-7-506x824.jpeg" alt="">
                                </div>
                            </div>
                            <ol class="carousel-indicators">
                                <li data-slide-to="0" data-bs-slide-to="0" class="active" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK"></li><li data-slide-to="1" data-bs-slide-to="1" class="" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK"></li><li data-slide-to="2" data-bs-slide-to="2" class="" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK"></li><li data-slide-to="3" data-bs-slide-to="3" class="" data-target="#lb-sRH7Kx4CvK" data-bs-target="#lb-sRH7Kx4CvK"></li>
                            </ol>
                            <a role="button" href="" class="close" data-dismiss="modal" data-bs-dismiss="modal" aria-label="Close">
                            </a>
                            <a class="carousel-control-prev carousel-control" role="button" data-slide="prev" data-bs-slide="prev" href="#lb-sRH7Kx4CvK">
                                <span class="mobi-mbri mobi-mbri-arrow-prev" aria-hidden="true"></span>
                                <span class="sr-only visually-hidden">Previous</span>
                            </a>
                            <a class="carousel-control-next carousel-control" role="button" data-slide="next" data-bs-slide="next" href="#lb-sRH7Kx4CvK">
                                <span class="mobi-mbri mobi-mbri-arrow-next" aria-hidden="true"></span>
                                <span class="sr-only visually-hidden">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="team2 cid-sRCzqYSCoA" id="team2-s" style="background: linear-gradient(90deg, rgb(43 124 188) 0%, rgb(178 142 208) 59%, rgb(214 145 202) 95%);">
    
    
    <div class="container">
        <div class="card">
            <div class="card-wrapper">
                <div class="row align-items-center">
                    <div class="col-12 col-md-4">
                        <div class="image-wrapper">
                            <img src="<?php echo site::url(1);?>/img/n/thumbnail-695x704.jpg" alt="Mobirise">
                        </div>
                    </div>
                    <div class="col-12 col-md" style="padding:0;">
                        <div class="card-box" style="padding-right:7.7px;">
                            <h5 class="card-title mbr-fonts-style m-0 mb-3 display-5">
                                <strong>SERVICE</strong></h5>
                            <p class="mbr-text mbr-fonts-style display-7">I provide the following braiding services: BoxBraids, Knotless Braids, Goddess Locs, Passion Twists, Lemonade Braids, Tribal Braids, Feed-in Braids, Crotchet Braids, Cornrows and more.<br><br>Deposit is required to secure appointment.<br><strong>3hrs or Less</strong><br>Follow Us @cocohairsignature.</p>
                            <div class="social-row display-7" style="display: flex;">
                                <div style="margin-right: 12px;" class="soc-item">
                                    <a href="https://www.facebook.com/cocohairsignature/" target="_blank" style="width:30px;display: block;">
                                    <img src="<?php echo site::url(1);?>/img/n/facebooklogo.png?-695x704.jpg" style="width:100%"/>  
                                    </a>
                                </div>
                                <div class="soc-item">
                                    <a href="https://instagram.com/cocohairsignature" target="_blank" style="width:30px;display: block;">
                                        <img src="<?php echo site::url(1);?>/img/n/instagramlogo.png?-695x704.jpg" style="width:100%"/>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</section>


<?php include(dirr."/i/footer.php");?> 
   
</body>
</html>