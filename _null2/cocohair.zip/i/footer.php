 <section data-bs-version="5.1" class="footer3 cid-s48P1Icc8J mbr-reveal" once="footers" id="footer3-i">
    <div class="container">
        <div class="media-container-row align-center mbr-white">
            
            
            <div class="row row-copirayt">
                <p class="mbr-text mb-0 mbr-fonts-style mbr-white align-center display-7">© Copyright 2021 CocoHairSignature. All Rights Reserved.</p>
            </div>
            <div>
                <div style="font-size:21px;font-weight:600;padding:12px;padding-bottom:0;">SUBSCRIBE TO OUR NEWSLETTER</div><div>To get special offers, free giveaways, and once-in-a lifetime deals.</div>
                <form style="display:flex;margin-top:12px"><input type="text" name="sub_news_letter" style="width:70%;padding:9px;"><button style="width:30%;background:#e35a1e;color:#fff;">Subscribe</button></form></div>
        </div>
    </div>
</section>
<a href="https://mobirise.site/p" style="display:block;opacity:0;z-index:-999;"></a>


<script src="<?php echo site::url(1);?>/assets/bootstrap.bundle.min.js?<?php echo $rell;?>"></script>
<script src="<?php echo site::url(1);?>/assets/navbar-dropdown.js?<?php echo $rell;?>"></script>