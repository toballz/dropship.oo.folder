<html>
    
    <head> 
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width" />
        <title>Admin</title>
    </head>
    <body style="position:relative;">
        <div style="width:100%;max-width:500px;margin:auto;height:100%;position:relative;">
            <iframe src="./web/index.html" style="width:100%;height:100%;border:0;"></iframe>
        </div>
    </body>
    
</html>