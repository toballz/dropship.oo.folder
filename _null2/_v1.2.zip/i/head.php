<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="<?php echo site::url(1);?>/img/n/logo.png" type="image/x-icon">
  <meta name="description" content="">
  
  <base href="<?php echo site::url(1);?>"/>

 
 


  <link rel="stylesheet" href="<?php echo site::url(1);?>/assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="<?php echo site::url(1);?>/assets/bootstrap.min.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Inconsolata:200,300,400,500,600,700,800,900&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata:200,300,400,500,600,700,800,900&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Architects+Daughter:400&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Architects+Daughter:400&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Hind+Siliguri:300,400,500,600,700&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Hind+Siliguri:300,400,500,600,700&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Jost:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
   
  <link rel="stylesheet" href="<?php echo site::url(1);?>/assets/css.css">
<script type="text/javascript" src="<?php echo site::url(1);?>/assets/jq.js"></script>
 
<script type="text/javascript" src="<?php echo site::url(1);?>/3rdparty/datepicker4/js/pignose.calendar.full.min.js"></script>
  