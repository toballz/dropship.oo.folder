<section class="menu cid-s48OLK6784" id="menu1-n">
    
    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="container">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-5" style="padding-right:12px;" href="<?php echo site::url(1);?>/index.php">CocoHairSignature</a></span>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true">
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="<?php echo site::url(1);?>/pages/hairlist.php"><span class="mobi-mbri mobi-mbri-timer mbr-iconfont mbr-iconfont-btn"></span>Book Now</a></li>
                    <li class="nav-item"><a class="nav-link link text-black text-primary display-4" href="http://shop.<?php echo site::url(3);?>"><span class="mobi-mbri mobi-mbri-cart-add mbr-iconfont mbr-iconfont-btn"></span>Shop Online</a></li>
                </ul>
            </div>
        </div>
    </nav>

</section>