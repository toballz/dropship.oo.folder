<?php include_once("../co.php");?><!DOCTYPE html>
<html>
<head> 

  <?php include(dirr."/i/head.php");?>
  <title>Home</title>
  
  
</head>
<body>
<?php include(dirr."/i/header.php");?>
<section data-bs-version="5.1" class="content5 cid-sRCtHKvscz" id="content5-q">
    
    <div class="container">
        <div class="row justify-content-center">
            <h1>📚1on1 Classes</h1>
            <div class="col-md-12 col-lg-10" style="max-width:1200px;background:#fbdddd;padding:12px;border-radius:12px;margin-bottom:21px;">
                <div><b>PLEASE MESSAGE ME BEFORE YOU BOOK THIS SERVICE</b><br/><b>Cocohairsignature@gmail.com</b><br/><br/><b>-Beginners Braiding Course (8 hours @ $1,100)</b><br/>•In this course, you will learn about the basics of braiding.<br/> •You are going to complete 1 full head of braids. <br/> •Mannequin head, starter kit and certificate of completion included.<br/><b>We will cover:</b><br/> -Products used<br/> -Different braiding hair/prepping hair <br/> -Parting/brick layering<br/> -Sizing<br/> -Cornrows with and without extensions<br/> -Individual plaits, with and without extensions, with and without knots<br/> -Finishing techniques<br/> -Growing your clientele<br/> -Pricing when practicing </div>
            </div>

            <div class="col-md-12 col-lg-10" style="max-width:1200px;background:#fbdddd;padding:12px;border-radius:12px;">
                <div><b>Advanced Braiding Course (8 hours @ $1,100)</b><br/> •For this course, a basic knowledge of braiding is required.<br/> •Live model required.<br/> •Certificate of completion included<br/><b>We will cover:</b><br/> -Hair and products used<br/> -Parting/brick layering<br/> -Sizing<br/> -Extending braids<br/> -Tuck method<br/> -Custom ombre<br/> -Finishing techniques<br/> -Pro-photography tips<br/> -Social media branding/marketing<br/></div>
            </div>
    </div>
</section>


<?php include(dirr."/i/footer.php");?>

 
   
  
</body>
</html>